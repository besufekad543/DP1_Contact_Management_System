		</div><!-- content -->
		<?php	mysqli_close($conn); ?>
		<div id="footer">
			<!--<?php echo 'Copyright &copy; '.date('Y').' www.polito.it'; ?>-->
			<?php echo 'Copyright &copy; '.date('Y').' s202500@polito.it'; ?>
		</div><!-- footer -->

	</div><!-- page -->
</div><!-- container -->
</body>
</html>

